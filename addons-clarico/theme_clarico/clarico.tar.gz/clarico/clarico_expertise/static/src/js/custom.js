$(document).ready(function(){

	$('.progressbar2').progressBar({
	shadow : true,
	percentage : true,
	animation : true,
	barColor : "#000000",
	});
	

});
